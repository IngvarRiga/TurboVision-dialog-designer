//-- use correspond lang define in progect option
//-- see: multilang.h

#include <cstdlib>
#include "tprg.h"
using namespace std;


int main(int argc, char** argv)
{
    TPrg prg;
    prg.run();
    return 0;
}

